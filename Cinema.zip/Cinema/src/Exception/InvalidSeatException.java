package Exception;

public class InvalidSeatException extends Exception {
    public InvalidSeatException(String message) {
        super(message); // Pass the message to the superclass constructor
    }
}


